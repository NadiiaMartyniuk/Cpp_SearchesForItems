#include <iostream>
#include<string>
#include<fstream>
#include<sstream>

using namespace std;

void WczytanieStudentow(struct student *&tab, int *n);
void WyswietlanieStudentow(struct student *&tab, int *n);
void zadanie7_1(struct student *&tab, int *n);
void deleteTab(struct student *&tab);
void zadanie7_2(struct student *&tab, int n);
void zadanie7_3(struct student *&tab, int n);
void sortowanieQuickSort(student*& tab, int lewy, int prawy);
void wyszukiwanieBisekcyjne(struct student*&tab, int n, int wartosc);


struct student {
    string imie;
    string nazwisko;
    int punkty;
};

void WczytanieStudentow(struct student *&tab, int *n){
    string sciezka, linia;
    int liczbaStudentow;
    ifstream plik;
    char srednik;
    plik.open("studenci.csv");
    plik >> liczbaStudentow;
    tab = new student [liczbaStudentow];
    for (int i=0; i<2; i++)
        plik >>srednik;
    for (int i=0; i<liczbaStudentow; i++){
        plik >> linia;
        istringstream ss(linia);
        getline(ss, tab[i].imie, ';');
        getline(ss, tab[i].nazwisko, ';');
        string punkty_str;
        getline(ss, punkty_str, ';');
        tab[i].punkty = stoi(punkty_str);
    }
    *n=liczbaStudentow;
    plik.close();
}

void WyswietlanieStudentow(struct student *&tab, int n){
    for (int i=0; i<n; i++){
        cout << tab[i].imie << " " << tab[i].nazwisko << " " << tab[i].punkty<<endl;
    }
}

void zadanie7_1(struct student *&tab, int *n){
    WczytanieStudentow(tab, n);
    cout<<"TABLICA STUDENTOW"<<endl;
    WyswietlanieStudentow(tab, *n);

}
void deleteTab(struct student *&tab){
    delete [] tab;
}

void zadanie7_2(struct student *&tab, int n){
    int liczbapunktow;
    cout<<"Podaj liczbe punktow ";
    cin>>liczbapunktow;
    int czy_sa;
    czy_sa=0;
    for (int i=0; i<n; i++){
        if (tab[i].punkty==liczbapunktow){
            if (czy_sa==0){
                cout << "Studenci, ktorzy otrzymali "<<liczbapunktow <<" "<<endl;
                czy_sa=1;
            }
            cout << tab[i].imie << " " << tab[i].nazwisko << " " << tab[i].punkty<<endl;

        }
    }
    if (czy_sa==0){
        cout << "Nie znalezono studentow z taka liczba punktow "<<endl;
    }

}

void zadanie7_3(struct student *&tab, int n){
    int lewy, wartosc;
    lewy =0;
    sortowanieQuickSort(tab, lewy, n-1);
    cout<<"Podaj liczbe punktow ";
    cin>>wartosc;
    student *tabKopia = new student [n];
    for (int i=0; i<n; i++){
        tabKopia[i]=tab[i];
    }
    wyszukiwanieBisekcyjne(tabKopia, n, wartosc);

}

void wyszukiwanieBisekcyjne(struct student *&tab, int n, int wartosc){
    int lewy, prawy, srodek, czy_znalezono;
    lewy =0;
    prawy=n-1;
    czy_znalezono=0;
    while(lewy<=prawy){
        srodek=(lewy+prawy)/2;
        if (tab[srodek].punkty==wartosc){
            if (czy_znalezono==0){
               cout << "Studenci, ktorzy otrzymali "<<wartosc<<" punktow"<<endl;
               ofstream zapis;
               string sciezkaDoZapisu="wyniki.csv";
               zapis.open(sciezkaDoZapisu);
               zapis<<tab[srodek].imie<<";"<<tab[srodek].nazwisko<<";"<<tab[srodek].punkty<<endl;
               zapis.close();
            }
            cout << tab[srodek].imie << " " << tab[srodek].nazwisko << " " << tab[srodek].punkty<<endl;
            if (czy_znalezono==1){
                ofstream plik("wyniki.csv", ios::app); // dopisywanie
                if (plik.is_open()) {
                    plik<<tab[srodek].imie<<";"<<tab[srodek].nazwisko<<";"<<tab[srodek].punkty<<endl;
                    plik.close();
                }
            }
            czy_znalezono=1;
            for (int i = srodek; i < n-1; i++) {
                tab[i] = tab[i+1];
            }
            n--;
            lewy =0;
            prawy=n-1;

        }
        else{
            if (wartosc<tab[srodek].punkty)
                prawy=srodek-1;
            else
                lewy=srodek+1;
        }
   }
   if (czy_znalezono==0){
        cout << "Nie znalezono studentow z taka liczba punktow "<<endl;
               ofstream zapis;
               string sciezkaDoZapisu="wyniki.csv";
               zapis.open(sciezkaDoZapisu);
               zapis<<"Studentow z taka liczba punktow nie znalezono"<<endl;
               zapis.close();
   }
}

void sortowanieQuickSort(student*& tab, int lewy, int prawy){
        int piwotpunkty, srodek, granica, i;
        struct student piwot;
        srodek=(lewy+prawy)/2;
        piwot=tab[srodek];
        piwotpunkty=tab[srodek].punkty;
        tab[srodek]=tab[prawy];
        granica=lewy;
        i=lewy;
        while(i<prawy){
            if(tab[i].punkty<piwotpunkty){
                swap(tab[granica], tab[i]);
                granica +=1;

            }
            i +=1;
        }
        tab[prawy]=tab[granica];
        tab[granica]=piwot;
            if (lewy<granica-1){
                sortowanieQuickSort(tab,lewy,granica-1);
            }
            if (granica+1<prawy){
                sortowanieQuickSort(tab, granica+1,prawy);
            }
    }

int main()
{
    student *tab = nullptr ;
    int n, jakieZadanie, czyPiersze;
    jakieZadanie = 0;
    czyPiersze = 0;
    while (jakieZadanie!=4){
    cout<<endl;
    cout<<"1 - Wczytanie danych z pliku"<<endl;
    cout<<"2 - Wyszukiwanie liniowe"<<endl;
    cout<<"3 - Wyszukiwanie bisekcyjne"<<endl;
    cout<<"4 - Konczy program "<<endl;
    cout<<"Jaki zadanie chcesz wykonac ? ";
    cin>>jakieZadanie;
    if (jakieZadanie==1){
        if (czyPiersze==1)
            cout<<"Dane juz zostali wczytane wcesniej"<<endl;
        else{
            zadanie7_1(tab, &n);
            czyPiersze=1;
        }

    }
    else{
        if (jakieZadanie==2){
            if (czyPiersze){
                zadanie7_2(tab, n);
            }
            else
                cout<<"Dane musza byc wczytane"<<endl;

        }

        else{
            if (jakieZadanie==3){
                if (czyPiersze){
                zadanie7_3(tab, n);
            }
            else
                cout<<"Dane musza byc wczytane"<<endl;
                }
            else{
                if (jakieZadanie == 4)
                    cout<<"Pa !"<<endl;
               else
                    cout<<"Nie ma takie opcji"<<endl;
            }


        }
    }}

    deleteTab(tab);
    return 0;
}
